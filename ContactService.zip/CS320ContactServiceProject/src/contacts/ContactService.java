package contacts;

import java.util.HashMap;
import java.util.Map;

public class ContactService {

    // In-memory store keyed by contactID
    private final Map<String, Contact> contacts = new HashMap<>();

    // --- Add ---
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("contact cannot be null");
        }
        String id = contact.getContactID();
        if (id == null) {
            throw new IllegalArgumentException("contactID cannot be null");
        }
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("contactID must be unique");
        }
        contacts.put(id, contact);
    }

    // --- Delete by ID ---
    public void deleteContact(String contactID) {
        if (contactID == null) {
            throw new IllegalArgumentException("contactID cannot be null");
        }
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("contact not found");
        }
        contacts.remove(contactID);
    }

    // --- Update fields by ID (ID itself is not updatable) ---
    public void updateFirstName(String contactID, String newFirstName) {
        Contact c = getRequired(contactID);
        c.setFirstName(newFirstName);
    }

    public void updateLastName(String contactID, String newLastName) {
        Contact c = getRequired(contactID);
        c.setLastName(newLastName);
    }

    public void updatePhone(String contactID, String newPhone) {
        Contact c = getRequired(contactID);
        c.setPhone(newPhone);
    }

    public void updateAddress(String contactID, String newAddress) {
        Contact c = getRequired(contactID);
        c.setAddress(newAddress);
    }

    // Optional helpers (handy for tests)
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }

    public boolean exists(String contactID) {
        return contacts.containsKey(contactID);
    }

    // --- Internal guard ---
    private Contact getRequired(String contactID) {
        if (contactID == null) {
            throw new IllegalArgumentException("contactID cannot be null");
        }
        Contact c = contacts.get(contactID);
        if (c == null) {
            throw new IllegalArgumentException("contact not found");
        }
        return c;
    }
}