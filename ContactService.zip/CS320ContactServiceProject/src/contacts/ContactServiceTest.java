package contacts;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

    @Test
    void addContact_succeedsAndIsRetrievable() {
        ContactService svc = new ContactService();
        Contact c = new Contact("A1", "Sam", "Lee", "1234567890", "1 Main St");
        svc.addContact(c);

        assertTrue(svc.exists("A1"));
        assertEquals("Sam", svc.getContact("A1").getFirstName());
    }

    @Test
    void addContact_rejectsDuplicateId() {
        ContactService svc = new ContactService();
        svc.addContact(new Contact("A1", "Sam", "Lee", "1234567890", "1 Main St"));

        assertThrows(IllegalArgumentException.class,
            () -> svc.addContact(new Contact("A1", "Ben", "Kay", "0987654321", "2 Oak Ave")));
    }

    @Test
    void deleteContact_removesById() {
        ContactService svc = new ContactService();
        svc.addContact(new Contact("A1", "Sam", "Lee", "1234567890", "1 Main St"));
        svc.deleteContact("A1");

        assertFalse(svc.exists("A1"));
        assertNull(svc.getContact("A1"));
    }

    @Test
    void deleteContact_throwsWhenMissing() {
        ContactService svc = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> svc.deleteContact("NOPE"));
    }

    @Test
    void updateFirstName_byId() {
        ContactService svc = new ContactService();
        svc.addContact(new Contact("A1", "Sam", "Lee", "1234567890", "1 Main St"));

        svc.updateFirstName("A1", "Ben");
        assertEquals("Ben", svc.getContact("A1").getFirstName());
    }

    @Test
    void updateLastName_byId() {
        ContactService svc = new ContactService();
        svc.addContact(new Contact("A1", "Sam", "Lee", "1234567890", "1 Main St"));

        svc.updateLastName("A1", "Kay");
        assertEquals("Kay", svc.getContact("A1").getLastName());
    }

    @Test
    void updatePhone_byId() {
        ContactService svc = new ContactService();
        svc.addContact(new Contact("A1", "Sam", "Lee", "1234567890", "1 Main St"));

        svc.updatePhone("A1", "0987654321");
        assertEquals("0987654321", svc.getContact("A1").getPhone());
    }

    @Test
    void updateAddress_byId() {
        ContactService svc = new ContactService();
        svc.addContact(new Contact("A1", "Sam", "Lee", "1234567890", "1 Main St"));

        svc.updateAddress("A1", "2 Oak Ave");
        assertEquals("2 Oak Ave", svc.getContact("A1").getAddress());
    }

    @Test
    void updates_enforceValidationRules() {
        ContactService svc = new ContactService();
        svc.addContact(new Contact("A1", "Sam", "Lee", "1234567890", "1 Main St"));

        assertThrows(IllegalArgumentException.class, () -> svc.updateFirstName("A1", "ABCDEFGHIJK")); // >10
        assertThrows(IllegalArgumentException.class, () -> svc.updateLastName("A1", "ABCDEFGHIJK"));  // >10
        assertThrows(IllegalArgumentException.class, () -> svc.updatePhone("A1", "1111"));            // not 10
        assertThrows(IllegalArgumentException.class, () -> svc.updateAddress("A1",
                "1234567890123456789012345678901")); // >30
    }

    @Test
    void updateOrDelete_missingId_throws() {
        ContactService svc = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> svc.updateFirstName("NOPE", "A"));
        assertThrows(IllegalArgumentException.class, () -> svc.updateLastName("NOPE", "B"));
        assertThrows(IllegalArgumentException.class, () -> svc.updatePhone("NOPE", "1234567890"));
        assertThrows(IllegalArgumentException.class, () -> svc.updateAddress("NOPE", "Addr"));
    }
}