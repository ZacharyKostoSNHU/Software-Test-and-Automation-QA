package contacts;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void createsValidContact() {
        Contact c = new Contact("ID123", "Alice", "Smith", "1234567890", "10 Main St");
        assertEquals("ID123", c.getContactID());
        assertEquals("Alice", c.getFirstName());
        assertEquals("Smith", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("10 Main St", c.getAddress());
    }

    // --- contactID rules ---
    @Test
    void nullIdThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact(null, "A", "B", "1234567890", "Addr"));
    }

    @Test
    void idOverTenThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ABCDEFGHIJK", "A", "B", "1234567890", "Addr")); // 11 chars
    }

    // --- firstName rules ---
    @Test
    void nullFirstNameThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", null, "B", "1234567890", "Addr"));
    }

    @Test
    void firstNameOverTenThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "ABCDEFGHIJK", "B", "1234567890", "Addr"));
    }

    // --- lastName rules ---
    @Test
    void nullLastNameThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "A", null, "1234567890", "Addr"));
    }

    @Test
    void lastNameOverTenThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "A", "ABCDEFGHIJK", "1234567890", "Addr"));
    }

    // --- phone rules ---
    @Test
    void nullPhoneThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "A", "B", null, "Addr"));
    }

    @Test
    void phoneMustBeExactlyTenDigits_short() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "A", "B", "12345", "Addr"));
    }

    @Test
    void phoneMustBeExactlyTenDigits_long() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "A", "B", "12345678901", "Addr"));
    }

    // --- address rules ---
    @Test
    void nullAddressThrows() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "A", "B", "1234567890", null));
    }

    @Test
    void addressOverThirtyThrows() {
        String over30 = "1234567890123456789012345678901"; // 31
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("ID", "A", "B", "1234567890", over30));
    }

    // --- setters update allowed fields and keep ID unchanged ---
    @Test
    void settersWorkAndIdStaysTheSame() {
        Contact c = new Contact("CONSTID", "A", "B", "1234567890", "Addr");
        c.setFirstName("Ben");
        c.setLastName("Lee");
        c.setPhone("0987654321");
        c.setAddress("20 Oak Ave");

        assertEquals("CONSTID", c.getContactID());
        assertEquals("Ben", c.getFirstName());
        assertEquals("Lee", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("20 Oak Ave", c.getAddress());
    }

    @Test
    void settersEnforceValidation() {
        Contact c = new Contact("ID", "A", "B", "1234567890", "Addr");
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName("ABCDEFGHIJK"));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("ABCDEFGHIJK"));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("1111"));
        assertThrows(IllegalArgumentException.class, () -> c.setAddress("1234567890123456789012345678901"));
    }
}